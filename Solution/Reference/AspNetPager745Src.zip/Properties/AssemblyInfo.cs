using System.Reflection;
using System.Runtime.CompilerServices;
using System.Web.UI;
using System.Security;


[assembly: AssemblyTitle("AspNetPager 7.4.5")]
[assembly: AssemblyDescription("ASP.NET��ҳ�ؼ�")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("�����������޹�˾")]
[assembly: AssemblyProduct("AspNetPager")]
[assembly: AssemblyCopyright("Webdiyer")]
[assembly: AssemblyTrademark("Webdiyer")]
[assembly: AssemblyCulture("")]		
[assembly: TagPrefix("Wuqi.Webdiyer","webdiyer")]
[assembly: AssemblyVersion("7.4.5")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyName("")]
[assembly: AllowPartiallyTrustedCallers()]
