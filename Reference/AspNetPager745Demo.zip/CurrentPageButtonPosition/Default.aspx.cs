using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

public partial class CenterCurrentPageButton_Default : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }

}
