﻿using System;
public partial class Styles1_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
    }


}
